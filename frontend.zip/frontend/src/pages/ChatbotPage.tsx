import React, { useState } from 'react';
import axios from 'axios';

const ChatbotPage: React.FC = () => {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<{ text: string; sender: 'user' | 'bot' }[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleSend = async () => {
    if (!query.trim()) return;

    setMessages(prev => [...prev, { text: query, sender: 'user' }]);

    try {
      const response = await axios.post('http://localhost:5000/api/chat', { message: query });
      const botReply = response.data?.response || 'No response received.';
      setMessages(prev => [...prev, { text: botReply, sender: 'bot' }]);
    } catch (err) {
      console.error('Error:', err);
      setMessages(prev => [
        ...prev,
        { text: '⚠️ Failed to fetch response. Please check your server.', sender: 'bot' }
      ]);
      setError('Server error. Check backend or API key.');
    }

    setQuery('');
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Segoe UI' }}>
      <h2>💬 <strong>Gemini AI Chatbot</strong></h2>

      <div style={{
        background: '#f5f6fa',
        padding: '20px',
        borderRadius: '10px',
        height: '350px',
        overflowY: 'auto',
        marginBottom: '10px',
        border: '1px solid #ccc'
      }}>
        {messages.map((msg, index) => (
          <div
            key={index}
            style={{
              textAlign: msg.sender === 'user' ? 'right' : 'left',
              marginBottom: '10px'
            }}
          >
            <span style={{
              display: 'inline-block',
              padding: '10px 15px',
              borderRadius: '20px',
              backgroundColor: msg.sender === 'user' ? '#4e8cff' : '#dcdde1',
              color: msg.sender === 'user' ? 'white' : 'black',
              maxWidth: '80%'
            }}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex' }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Ask your query here..."
          style={{
            flex: 1,
            padding: '10px',
            borderRadius: '5px',
            border: '1px solid black',
            fontSize: '16px'
          }}
        />
        <button
          onClick={handleSend}
          style={{
            marginLeft: '10px',
            padding: '10px 20px',
            backgroundColor: '#28a745',
            color: 'white',
            borderRadius: '5px',
            cursor: 'pointer',
            border: 'none',
            fontSize: '16px'
          }}
        >
          Send
        </button>
      </div>

      {error && <p style={{ color: 'red', marginTop: '10px' }}>{error}</p>}
    </div>
  );
};

export default ChatbotPage;
