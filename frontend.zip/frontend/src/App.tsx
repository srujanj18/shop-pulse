import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Deals from "./pages/Deals";
import Navbar from "@/components/Navbar";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import CategoryPage from "./pages/Categories";
import ProductsPage from "./pages/ProductsPage";
import Chatbot from "./pages/ChatbotPage";

import ChatbotPage from "./pages/ChatbotPage"; // ✅

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/categories" element={<CategoryPage />} /> {/* ✅ Added */}
          <Route path="/category/:category" element={<CategoryPage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/deals" element={<Deals />} /> {/* ✅ Add this */}
          <Route path="*" element={<NotFound />} /> {/* 404 fallback */}
          <Route path="*" element={<NotFound />} />
           <Route path="/chatbot" element={<Chatbot />} />
           <Route path="/chatbot" element={<ChatbotPage />} /> {/* ✅ Add this */}
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
