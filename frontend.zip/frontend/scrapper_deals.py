from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import time
import json

AFFILIATE_TAG = "bestdeal03ff2-21"
OUTPUT_FILE = "brand_deals.json"

# Exact brand names to match
BRANDS = [
    "OnePlus", "iQOO", "Samsung", "Redmi", "HP", "LG", "Xiaomi", "Sony", "VIVO",
    "realme", "Apple", "RR", "POCO", "Vu", "HONOR", "TCL", "Lava", "Lenovo", "acer", "Bosch"
]

def fetch_brand_deals():
    print("🔍 Scraping brand-specific deals from Amazon...")

    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get("https://www.amazon.in/deals")

    time.sleep(6)  # Wait for the page to fully load

    deals = []
    seen = set()

    links = driver.find_elements(By.XPATH, "//a[contains(@href, '/dp/')]")

    for link in links:
        try:
            title = link.get_attribute("aria-label") or ""
            href = link.get_attribute("href")
            img_tag = link.find_element(By.XPATH, ".//img")
            img_url = img_tag.get_attribute("src") if img_tag else ""

            if not title or not href or href in seen:
                continue

            # Check brand match (case-insensitive, full word match)
            matched_brand = next((brand for brand in BRANDS if brand.lower() in title.lower()), None)
            if matched_brand:
                deals.append({
                    "title": title.strip(),
                    "price": "N/A",  # Can be scraped later if needed
                    "image": img_url,
                    "url": href.split("?")[0] + f"?tag={AFFILIATE_TAG}",
                    "category": matched_brand
                })
                seen.add(href)

        except Exception as e:
            print("⚠️ Error:", e)

    driver.quit()
    return deals

def save_deals(deals):
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(deals, f, indent=2, ensure_ascii=False)
    print(f"✅ {len(deals)} deals saved to {OUTPUT_FILE}")

def main():
    deals = fetch_brand_deals()
    if deals:
        save_deals(deals)
    else:
        print("⚠️ No deals found.")

if __name__ == "__main__":
    main()
